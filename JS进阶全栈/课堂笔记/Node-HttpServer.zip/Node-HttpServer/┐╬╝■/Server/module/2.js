// globa.a = 2;

let a = 2;

// console.log(module);

exports.v = a;