/**
 * 模块也可以通过一个目录的形式来组织
 *  默认情况下会加载目录模块下的index.js，作为目录模块的入口
 */
let miaov = require('./miaov');

console.log(miaov);