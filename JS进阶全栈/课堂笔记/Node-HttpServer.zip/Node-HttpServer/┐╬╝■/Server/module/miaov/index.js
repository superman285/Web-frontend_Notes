let fn = require('./fn');

exports.v = 'miaov - index';
exports.fn = fn;