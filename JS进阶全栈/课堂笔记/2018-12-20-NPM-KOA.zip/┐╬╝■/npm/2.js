const $ = require('jquery');
console.log($);