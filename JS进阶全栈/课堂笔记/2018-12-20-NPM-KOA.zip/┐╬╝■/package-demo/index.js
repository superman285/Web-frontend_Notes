// const $ = require('jquery');

console.log('Hello Miaov');