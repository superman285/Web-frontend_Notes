class Alert extends Modal {
    
}