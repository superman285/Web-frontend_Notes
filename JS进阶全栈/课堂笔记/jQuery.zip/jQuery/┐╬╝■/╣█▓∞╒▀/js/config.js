const configs = {
    modalType: 'confirm'
}